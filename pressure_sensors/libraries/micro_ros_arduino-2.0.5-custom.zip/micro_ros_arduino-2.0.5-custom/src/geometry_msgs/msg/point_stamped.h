// generated from rosidl_generator_c/resource/idl.h.em
// with input from geometry_msgs:msg/PointStamped.idl
// generated code does not contain a copyright notice

#ifndef GEOMETRY_MSGS__MSG__POINT_STAMPED_H_
#define GEOMETRY_MSGS__MSG__POINT_STAMPED_H_

#include "geometry_msgs/msg/detail/point_stamped__struct.h"
#include "geometry_msgs/msg/detail/point_stamped__functions.h"
#include "geometry_msgs/msg/detail/point_stamped__type_support.h"

#endif  // GEOMETRY_MSGS__MSG__POINT_STAMPED_H_
