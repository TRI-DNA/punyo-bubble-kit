// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_msgs:msg/UInt16.idl
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__U_INT16_H_
#define STD_MSGS__MSG__U_INT16_H_

#include "std_msgs/msg/detail/u_int16__struct.h"
#include "std_msgs/msg/detail/u_int16__functions.h"
#include "std_msgs/msg/detail/u_int16__type_support.h"

#endif  // STD_MSGS__MSG__U_INT16_H_
